vars = {
    "PhoneNumber": 918459291908,
    "ToGroup": "https://t.me/+gZx2rit3Csc3ZmE1",
    "EnterStop": 350000,
    "Language": "en",
    "Per_account_add": 5,
    "StartingAccount": 1,
    "EndAccount": 700,
    "Message_file": "",
    "USERNAME": "ok",
    "last_seen": 86400,
}
